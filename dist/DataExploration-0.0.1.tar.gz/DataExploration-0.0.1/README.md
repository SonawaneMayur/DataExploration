Analysis of all Big Data files like parquet file and
generate the descriptive stats, character encoding,
regression analysis for each column exist in the file